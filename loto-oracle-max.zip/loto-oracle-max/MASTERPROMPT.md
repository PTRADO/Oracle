# MASTERPROMPT — ORACLE MAX (Claude Code)

> Colle ce fichier à la racine du projet. Ouvre Claude Code dans le dossier et
> dis simplement : « Lis MASTERPROMPT.md et exécute la phase 1 ». Puis avance
> phase par phase. Chaque phase a sa Definition of Done.

---

## 1. RÔLE ET MISSION

Tu es lead dev sur **ORACLE**, un pronostiqueur Loto + EuroMillions
auto-hébergé. Le produit est déjà fonctionnel en v2.0 (moteur Python stdlib,
mini-app web glassmorphism, cron GitHub Actions). Ta mission : le pousser au
niveau produit fini — données réelles fiabilisées, calibration avancée, EV
temps réel, intégration dans l'app Next.js/Supabase de Thomas, notifications.

**Stack existante du projet** : Python 3.12 stdlib pure (moteur), HTML/CSS/JS
vanilla (page), GitHub Actions (cron). **Stack cible d'intégration** :
Next.js App Router + Supabase + N8N self-hosted (l'écosystème de Thomas).

## 2. GARDE-FOUS NON NÉGOCIABLES (à préserver dans CHAQUE évolution)

1. **Le backtest walk-forward ne sort JAMAIS du code ni de l'UI.** C'est le
   juge de paix qui prouve que le folklore (T1-T8) ne bat pas le hasard.
2. **Aucune promesse prédictive**, nulle part (code, UI, commits, README).
   Les seuls leviers réels et les seuls arguments autorisés : anti-partage
   calibré (montant, pas probabilité), EV/timing, surveillance χ².
3. **Aucune automatisation de prise de jeu** (pas de bot qui joue sur fdj.fr,
   pas de scraping du compte joueur). Le bouton « Jouer sur FDJ ↗ » reste un
   simple lien.
4. **La ligne jeu responsable reste visible** : « Jouer comporte des risques —
   09 74 75 13 13 (joueurs-info-service.fr) ».
5. **L'EV affichée reste honnête** (négative sauf cas extrêmes) — jamais
   maquillée, jamais renommée en « gain attendu ».
6. Usage personnel. Ne jamais transformer en service de vente de pronostics.

## 3. ÉTAT ACTUEL — v2.1 (livré, testé)

```
oracle.py                     # moteur bi-jeux, ~1000 lignes stdlib
docs/index.html               # mini-app glassmorphism (vanilla, 1 fichier)
docs/loto.json                # export démo (données synthétiques)
docs/euromillions.json        # export démo (données synthétiques)
.github/workflows/pronostics.yml  # cron quotidien 04h30 UTC
data/                         # mirrors CSV auto-alimentés par le cron
README.md · MASTERPROMPT.md
```

### Ce que fait le moteur (validé par tests)
- **Données** : téléchargement FDJ avec chaîne de secours (URL directe →
  auto-découverte par scrape de la page historique → mirror GitHub perso).
  Parser tolérant (variantes de colonnes, ZIP ou CSV, latin-1/utf-8).
- **T1-T8 folklore** documenté + **T9 anti-partage** en deux couches :
  heuristique (littérature) + **calibration empirique** : régression ridge
  `log(gagnants) ~ indicatrices des 49/50 numéros + tendance + jour`,
  résolue par équations normales + Gauss maison. Validée sur synthétique :
  corr(β, popularité injectée) = 0,91 (loto) / 0,87 (euro).
- **EV par grille** : `ev_fixe` (gains hors-jackpot mesurés dans l'historique
  via rapports×gagnants / participation estimée) + composante jackpot
  corrigée du partage attendu (`pop_rel` de la grille issue des β). Jackpot
  scrapé sur fdj.fr ou saisi ; la page recalcule l'EV en direct.
- **Système réducteur** `--systeme N` : couverture gloutonne, garantie
  « ≥3 bons si les 5 sortants sont dans le pool », re-vérifiée par assert.
- **Vérité** : backtest walk-forward, effet anniversaire (corr gagnants ↔
  numéros ≤31), test χ² de biais physique. Tout est rejoué à chaque maj.
- **Grand livre (v2.1)** : chaque annonce est verrouillée
  (`data/historique_{jeu}.json`, commité par le cron), puis réglée en euros
  aux rapports FDJ réels dès que le tirage tombe (tables de rangs officielles
  Loto 9 rangs / EuroMillions 13 rangs codées dans `rang_gagne`). Cumul
  misé/gagné/ROI par mode + rétro-simulation `--simulation N`. Testé sur
  cycles annonce→règlement synthétiques (loto et euro).
  ⚠ Garde-fou supplémentaire : ce compteur ne doit JAMAIS être masqué ni
  « lissé » — c'est l'anti-illusion structurel du produit.

### Commandes de vérification (à lancer avant toute modif)
```bash
python3 oracle.py --jeu loto --export-web docs/loto.json --systeme 9 --grilles 4
python3 oracle.py --jeu euromillions --export-web docs/euromillions.json
cd docs && python3 -m http.server 8000   # → contrôle visuel de la page
```

### Contrat JSON (versionné — ne pas casser sans bump `meta.version`)
`meta{jeu,nom,bonus_nom,bonus_pick,bonus_max,n_max,prix,jackpot,page_jeu,
prochain_tirage,…}` · `modes.{hybride,pronostic,anti}.{scores,classement,
bonus,grilles[{numeros,bonus,score,pop_rel}]}` · `ev_params{n_est,ev_fixe,
p_jackpot_inv,prix}` · `calibration{r2,beta,top_surjoues,top_delaisses}` ·
`systeme` · `verdicts{backtest,effet_anniversaire,chi2}` · `techniques`.

---

## 4. PHASES DE DÉVELOPPEMENT

### PHASE 1 — Fiabilisation données réelles ⚡ priorité
Le moteur n'a tourné que sur données synthétiques. Première exécution réelle :
- Lancer sur les vrais ZIP FDJ (loto puis euromillions). Corriger le parser
  sur les variantes réelles de colonnes (noms exacts des colonnes gagnants/
  rapports EuroMillions, lignes multi-formats, tirages spéciaux à exclure).
- Écrire des tests pytest du parser sur des extraits réels commités dans
  `tests/fixtures/` (5-10 lignes par époque de format).
- Ajouter un contrôle d'intégrité au chargement : dates monotones, doublons,
  trous > 7 jours signalés ; `meta.alertes[]` dans l'export.
- Gérer l'historique EuroMillions multi-fichiers (concaténer les époques).
- **DoD** : les deux jeux tournent sur données réelles en local ET via le
  workflow ; `docs/*.json` réels commités ; tests parser verts en CI.

### PHASE 2 — Calibration avancée
- Passer la calibration au **niveau rang** : régresser séparément
  log(gagnants rang k) pour 2-3 rangs bas (plus de signal, moins de bruit
  jackpot), puis moyenner les β pondérés par l'inverse de la variance.
- Intervalle de confiance sur chaque β (bootstrap par blocs temporels, 200
  itérations max, rester stdlib) → l'UI affiche β ± IC au survol.
- Validation croisée temporelle : calibrer sur 80% ancien, vérifier la
  corrélation des β sur 20% récent → score de stabilité dans `calibration`.
- Page « Atlas de popularité » (section UI) : les 49/50 numéros classés par
  β mesuré, avec IC — l'argument visuel du mode anti-partage.
- **DoD** : β stables entre deux moitiés temporelles (corr > 0,5 sur données
  réelles) ; atlas visible ; aucun changement du contrat JSON sans bump.

### PHASE 3 — EV temps réel
- Scraper jackpot robuste : page jeu FDJ + page résultats en secours,
  cache `data/jackpots.json` horodaté, historique des jackpots conservé.
- Décomposer l'EV dans l'UI (fixe / jackpot / prix) + phrase claire :
  « ce soir, chaque ticket “rend” X % de son prix ».
- Comparateur du jour : Loto vs EuroMillions, quelle EV est la moins
  mauvaise ce soir, en tenant compte des deux jackpots courants.
- Seuil d'alerte configurable : « préviens-moi si EV > -0,50 € » (consommé
  par la phase 6).
- **DoD** : jackpots réels affichés sans saisie manuelle ; comparateur
  fonctionnel ; EV recalculée live conservée.

### PHASE 4 — Wheeling avancé + optimiseur de budget
- Étendre `systeme_reducteur` : garanties paramétrables (3-si-5, 4-si-5,
  3-si-4), pools 7-14, avec vérification exhaustive systématique.
- Optimiseur de budget : « j'ai X € ce soir » → répartition optimale entre
  grilles simples anti-partage et système, maximisant couverture à EV égale.
- Afficher pour chaque système : coût, garantie, tableau des scénarios
  (« si 3 des 5 sortants sont dans le pool → au minimum … »).
- **DoD** : garanties vérifiées par tests exhaustifs pytest ; optimiseur
  exposé en CLI (`--budget 20`) et dans l'UI.

### PHASE 5 — Intégration app Thomas (Next.js + Supabase)
- Créer `supabase/schema.sql` : tables `tirages`, `pronostics` (snapshot
  JSON par tirage), `mes_grilles` (grilles réellement jouées : numéros,
  bonus, mode, coût, tirage visé), `gains` (rang obtenu, montant).
- Deux voies au choix (implémenter la 1, documenter la 2) :
  1. **Simple** : l'app Next.js fetch les JSON raw GitHub (CORS ok) —
     composant React `<OraclePanel/>` portant l'UI actuelle.
  2. **Complète** : Edge Function Supabase qui exécute la logique d'import
     (port du parser en TS ou appel du JSON GitHub) + pg_cron.
- **Feature phare honnête** : le suivi de MES grilles (distinct du grand
  livre v2.1 qui suit les grilles ANNONCÉES — ici on suit celles réellement
  jouées par Thomas). Après chaque tirage,
  croiser `mes_grilles` × résultat réel → rang, gain, et le compteur cumulé
  « total joué / total gagné / ROI réel » affiché sans fard. C'est la
  meilleure protection anti-illusion jamais construite dans un pronostiqueur.
- **DoD** : page `/loto` dans l'app de Thomas affichant pronostics du jour +
  saisie « j'ai joué cette grille » + ROI cumulé après 1er tirage suivi.

### PHASE 6 — Notifications (N8N self-hosted de Thomas)
- Workflow N8N : chaque jour de tirage à 18h30 Paris, GET du JSON → si
  jackpot ≥ seuil OU EV > seuil configuré → message WhatsApp/email avec les
  3 grilles du mode anti, l'EV du soir, le lien FDJ. Jamais de push
  quotidien inconditionnel (anti-addiction by design : on notifie sur
  critère économique, pas pour faire jouer).
- Résumé post-tirage (lendemain 09h) : résultat, mes gains éventuels
  (phase 5), ROI cumulé.
- **DoD** : deux workflows N8N exportés en JSON dans `n8n/`, documentés.

### PHASE 7 — Qualité continue
- pytest sur : parser (fixtures réelles), calibration (jeu synthétique à
  popularité connue, corr > 0,6 exigée), EV (valeurs de référence), wheels
  (garanties exhaustives), contrat JSON (schéma).
- Workflow CI séparé (lint ruff + tests) sur PR.
- Budget perf page : < 100 Ko hors polices, rendu < 1s sur mobile.
- **DoD** : CI verte obligatoire, couverture des 4 modules critiques.

## 5. CONVENTIONS

- Moteur : **stdlib uniquement** (portabilité GitHub Actions/partout). Les
  deps (pytest, ruff) restent en dev only.
- Tout changement du contrat JSON ⇒ bump `meta.version` + rétrocompat page.
- Commits FR, préfixe emoji 🎱, messages descriptifs.
- Chaque phase = une branche + PR auto-review avant merge.
- En cas de doute produit : relire la section 2 (garde-fous). Elle gagne.

## 6. BACKLOG (après les phases, en vrac)

EuroDreams (rente) en 3e jeu · historique des β dans le temps (la popularité
des numéros évolue-t-elle ?) · PWA installable mobile · mode « entre potes »
(cagnotte partagée, grilles dédupliquées entre participants) · export PDF de
la fiche du soir · comparaison des sphères/jeux de boules FDJ si les données
d'identification des appareils deviennent publiques (χ² par sphère).
